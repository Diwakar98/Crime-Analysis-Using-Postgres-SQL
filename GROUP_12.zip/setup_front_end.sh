pip install numpy
pip install psycopg2-binary
pip install flask
